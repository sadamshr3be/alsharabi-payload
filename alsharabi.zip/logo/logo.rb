#!/data/data/com.termux/files/bin/ruby
=begin
Everything Is Possible. Let's Do!!!!
This is My First Program.. Don't Fear I Am NooB !!!


Name	        :   Mr.Payload
Code	        :   Ruby
sec.code      :   8h4i
Site.              :   http://bhai4you.blogspot.com
Coder           :   Sutariya Parixit
Github          :   https://github.com/Bhai4You


]=====> Don't Copy Or Modify...<=====[


=end
exec ("figlet -f big '        Mr. Payload' | lolcat")
